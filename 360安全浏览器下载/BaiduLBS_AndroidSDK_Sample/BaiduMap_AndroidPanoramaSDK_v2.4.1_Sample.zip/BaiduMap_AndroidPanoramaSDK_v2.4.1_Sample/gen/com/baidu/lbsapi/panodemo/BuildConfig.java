/** Automatically generated file. DO NOT MODIFY */
package com.baidu.lbsapi.panodemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}